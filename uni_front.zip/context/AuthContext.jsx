import {
createContext,
useContext,
useEffect,
useState
} from "react";


const AuthContext =
createContext();



export function AuthProvider({children}){


const [user,setUser]=useState(null);



useEffect(()=>{


const savedUser =
localStorage.getItem("user");

const token =
localStorage.getItem("token");



if(savedUser && token){

setUser(JSON.parse(savedUser));

}



},[]);




const loginUser=(userData,token)=>{


localStorage.setItem(
"user",
JSON.stringify(userData)
);


localStorage.setItem(
"token",
token
);


setUser(userData);

};



const logout=()=>{


localStorage.removeItem("user");

localStorage.removeItem("token");

setUser(null);

};



return (

<AuthContext.Provider

value={{
user,
setUser,
loginUser,
logout
}}

>

{children}

</AuthContext.Provider>

)

}



export const useAuth=()=>useContext(AuthContext);